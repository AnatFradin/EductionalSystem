## To install Structurizr:
#### Prerequisites  -  Docker Desktop installation:
1. Verify if you have WSL installed on your machine (usually no) buy running `wls` in Power Shell. 
If installed skip to `Docker Desktop` installation section.
2. Install WSL on windows as administrator
    - Open PowerShell with administrative privileges (IT is already aware).
    - Step by Step installation is here - https://learn.microsoft.com/en-us/windows/wsl/install-manual 
        - Restart is needed during the process
    - Open PowerShell (no need admin) to see if Ubuntu (insalled during the process) has wsl version 2
    ```
    wsl -l -v
    ```
    - If not, Open PowerShell (no need admin) and define default version for wls:  
    ```
    wsl --set-default-version 2
    ```
    - Reinstall the **Ubuntu** (from microsoft market place)
#### Docker Desktop
- Install Docker Desktop
Download and install from here https://docs.docker.com/desktop/install/windows-install/ 
Run Docker Desktop (if not run automatically)


#### Install Structurizr docker container
- Run following to install docker container

```
docker run -it -p 8080:8080 -v local_directory_where_diagram_is_placed:/usr/local/structurizr --name container_name_you_assign structurizr/lite
```

    e.g.: 
    ```
    docker run -it -p 8080:8080 -v D:\dev\GMP_2.0_CameraService:/usr/local/structurizr --name structurizr_POC structurizr/lite
    ```

#### Use Structurizr
- Start Strcuturizr container
- Go to the http://localhost:8080/

*** Notes:
- The `workspace.json` should be checked Out.
- Do NOT checkIn files that will be add to `.structurizr` directory during the work.