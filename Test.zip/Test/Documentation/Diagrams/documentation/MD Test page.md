
## Introduction Markdown file

Following is the c# piece of code \
New line

````` csharp
public static double Sum(double a, double b)
{
    return a + b;
}
`````

Here is my digram for Intergrate tool:
![](embed:Legacy_System_Context)


### Table
| Fruit  | Color  |
|--------|--------|
| Apple  | Red    |
| Banana | Yellow |
| Grapes | Purple |


### Link

[Google Link](https://www.google.com/) \
Bye
