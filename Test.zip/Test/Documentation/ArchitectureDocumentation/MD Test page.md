
## Introduction Markdown file

Following is the c# piece of code \
New line

````` csharp
public static double Sum(double a, double b)
{
    return a + b;
}
`````

Here is my digram for Intergrate tool:
![](embed:Legacy_System_Context)


### Table
| Fruit  | Color  |
|--------|--------|
| Apple  | Red    |
| Banana | Yellow |
| Grapes | Purple |


### Link

[Google Link](https://www.google.com/)\
Bye

```mermaid
flowchart TD

A[System / Architect] --> B[Create SRS]

B --> |SRS Provider| C[High-Level Design Stage]

C --> |System Architect/Designer| D[Create HLD]

D --> E[Low-Level Design Stage]

E --> |Developer| F[Create CDR]

F --> G[Implementation and Coding Stage]

G --> |Developer| H[Write Technical Documentation]

H --> |Developer| I[Update Module Guides]

H --> |Developer| J[Create/Update Walkthrough Guides]

I --> K[Testing Stage]

J --> K

K --> |QA Team| L[Develop Testing Documentation]

L --> M[Deployment and Maintenance Stage]

M --> |Technical Writers/Developers| N[User Manuals, Release Notes, Troubleshooting Guides]

M --> |System Administrators| O[System Admin Guides]

N --> P[Ongoing Documentation Maintenance]

O --> P

P --> |Developers, QA, Technical Writers| Q[Regularly Review and Update]

```