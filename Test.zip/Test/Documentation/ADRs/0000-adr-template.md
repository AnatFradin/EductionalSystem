# 1. Decision title

Date: 2023-07-31

## Status
Draft

```
Options: Draft / Proposed / Accepted / Superseded by / Rejected

If Superseded, mention by which ADR
```

## Decision
```
Brief description of the decision taken.
```

## Context

```
The forces and current contextual circumstances which have necessitated this decision
```


## Options Considered
```
Options considered: Each option considered, described briefly, with pros and cons. (Typically the option proposed/adopted comes first in this list)
```


## Consequences
```
The ramifications of this decision, both positive and negative
```

#### Positive:
- 
#### Negative:
- 

## Advice
```
Reflects the raw outputs from following the Advice Process. Can be provided directly by the advice-giver
```